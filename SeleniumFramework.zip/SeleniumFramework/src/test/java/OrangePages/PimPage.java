package OrangePages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PimPage extends base {

	public PimPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	public void pim() {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//span[normalize-space()='PIM']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='Employee List']")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Rohit");
		driver.findElement(By.xpath("//input[@placeholder='Middle Name']")).sendKeys("Kumar");
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("Bhunia");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//span[normalize-space()='My Info']")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[1]/div[2]/div/div/div[2]/input")).sendKeys("paul");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		   js.executeScript("window.scrollBy(0,500)");
		
		//driver.findElement(By.xpath("//div[contains(text(),'Japanese')]"));
		  // driver.findElement(By.xpath("//div[@clear='false'][normalize-space()='-- Select --']")).click();
		   /*
		   List<WebElement>drp4=driver.findElements(By.xpath("//div[contains(text(),'Single')]"));
			drp4.get(0).click();
			for(int i=0;i<drp4.size();i++) {
				drp4.get(0).sendKeys(Keys.ARROW_DOWN);
				
			}
			drp4.get(0).sendKeys(Keys.ENTER);
		   
		   //driver.findElement(By.xpath("//div[contains(text(),'Single')]")).click();
		   */
		   driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[3]/div[2]/div[1]/div/div[2]/div/div/i")).click();
		   driver.findElement(By.xpath("//label[normalize-space()='Female']//span[@class='oxd-radio-input oxd-radio-input--active --label-right oxd-radio-input']")).click();
		   driver.findElement(By.xpath("//div[@class='orangehrm-horizontal-padding orangehrm-vertical-padding']//button[@type='submit'][normalize-space()='Save']")).click();
		   
		   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		   
		   driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name'][normalize-space()='PIM']")).click();
		   driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/div[2]/form/div[1]/div/div[1]/div/div[2]/div/div/input")).sendKeys("John  Smith");
		   driver.findElement(By.xpath("//button[@type='submit']")).click();
		   driver.findElement(By.xpath("//button[@type='reset']")).click();
		   driver.findElement(By.xpath("//div[@class='oxd-table-card-cell-checkbox']//i[@class='oxd-icon bi-check oxd-checkbox-input-icon']")).click();
		   driver.findElement(By.xpath("//button[normalize-space()='Delete Selected']")).click();
		   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		   driver.findElement(By.xpath("//button[normalize-space()='No, Cancel']")).click();
		   
		   
	}

}
