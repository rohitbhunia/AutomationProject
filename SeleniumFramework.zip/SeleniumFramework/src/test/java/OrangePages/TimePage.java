package OrangePages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TimePage extends base{

	public TimePage(WebDriver driver) {
		super(driver);
}
	public void Time() throws InterruptedException {
		
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//span[normalize-space()='Time']")).click();
		driver.findElement(By.xpath("//span[normalize-space()='Time']")).click();
		
		String OptionToSelect="Peter Mac Anderson";
		int count=0;
		driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("Peter Mac Anderson");
		Thread.sleep(3000);
		
		List<WebElement>drp2=driver.findElements(By.xpath("//div[@class='oxd-autocomplete-dropdown --position-bottom']//li"));
		for(WebElement ele:drp2) {
			String currentOption=ele.getText();
			
			if(drp2.contains(OptionToSelect)) {
				ele.click();
				count++;
				break;
			}
		}
		if(count!=0) {
			System.out.println(OptionToSelect + "has been selected in the DD");
		}
		else {
			System.out.println("Option you want to select is not available in the DD");
		}
		/*
		drp2.get(0).click();
		for(int i=0;i<drp2.size();i++) {
			drp2.get(0).sendKeys(Keys.ARROW_DOWN);
			
		}
		drp2.get(0).sendKeys(Keys.ENTER);
		*/
		
		
		//driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[1]/form/hr")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
	
  }


