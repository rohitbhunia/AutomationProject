package OrangePages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class JobTitlepage extends base{

	public JobTitlepage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void JobTitle() throws InterruptedException {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//li[1]//a[1]//span[1]")).click();
		driver.findElement(By.xpath("//span[normalize-space()='Job']//i[@class='oxd-icon bi-chevron-down']")).click();
		driver.findElement(By.xpath("//li[@class='--active oxd-topbar-body-nav-tab --parent']//li[1]")).click();
		
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/input")).sendKeys("Manager");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//textarea[@placeholder='Type description here']")).sendKeys("Lead team, drive strategy, and ensure operational excellence. Manage resources, foster collaboration, and achieve organizational goals for success.");
		driver.findElement(By.xpath("//textarea[@placeholder='Add note']")).sendKeys("Very energetic");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		driver.findElement(By.xpath("//span[normalize-space()='Job']//i[@class='oxd-icon bi-chevron-down']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='Pay Grades']")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div/div/div[2]/input")).sendKeys("Odis  Adalwin");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Job']//i[@class='oxd-icon bi-chevron-down']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='Employment Status']")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/input")).sendKeys("FullTime");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Job']//i[@class='oxd-icon bi-chevron-down']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='Job Categories']")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/input")).sendKeys("IT");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[normalize-space()='Job']//i[@class='oxd-icon bi-chevron-down']")).click();
		driver.findElement(By.xpath("//a[normalize-space()='Work Shifts']")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div/div/div[2]/input")).sendKeys("Night Shift");
		driver.findElement(By.xpath("//div[@class='oxd-grid-4 orangehrm-full-width-grid']//div[1]//div[1]//div[2]//div[1]//div[1]//i[1]")).click();
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div/div[2]/div/div[2]/div[1]/input")).sendKeys("12");
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//input[@name='am']")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/div/div[2]/div/div[1]/i")).click();
		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/div/div[2]/div/div[2]/div[1]/input")).sendKeys("09");
		driver.findElement(By.xpath("//input[@name='pm']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("Nita Patel");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//div[@role='table']//div[1]//div[1]//div[6]//div[1]//button[1]//i[1]")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Yes, Delete']")).click();
		
		
		}
}
