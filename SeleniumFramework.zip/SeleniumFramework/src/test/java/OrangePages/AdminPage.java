package OrangePages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class AdminPage extends base{

	public AdminPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void Login() throws InterruptedException {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//li[1]//a[1]//span[1]")).click();
		driver.findElement(By.xpath("//button[normalize-space()='Add']")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		//Select drp=new Select(( By.xpath("//div[@class='oxd-select-text oxd-select-text--active' and @data-v-67d2aedf='']/div[@class='oxd-select-text-input']")));
		//drp.selectByIndex(0);
		
		List<WebElement>drp=driver.findElements(By.xpath("//div[@class='oxd-select-text oxd-select-text--active' and @data-v-67d2aedf='']/div[@class='oxd-select-text-input']"));
		drp.get(0).click();
		for(int i=0;i<drp.size();i++) {
			drp.get(0).sendKeys(Keys.ARROW_DOWN);
			
		}
		drp.get(0).sendKeys(Keys.ENTER);
			
		
	     List<WebElement>drp1=driver.findElements(By.xpath("//div[@class='oxd-select-text oxd-select-text--active' and @data-v-67d2aedf='']/div[@class='oxd-select-text-input']"));
	     drp1.get(0).click();
			for(int i=0;i<drp1.size();i++) {
				drp1.get(0).sendKeys(Keys.ARROW_DOWN);
				
			}
			drp1.get(0).sendKeys(Keys.ENTER);
		//driver.findElement(By.xpath("//div[@class='oxd-select-text oxd-select-text--active' and @data-v-67d2aedf='']/div[@class='oxd-select-text-input']")).click();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("Odis  Adalwin");
		driver.findElement(By.xpath("//div[@class='oxd-select-text oxd-select-text--active' and @data-v-67d2aedf=''][1]/div[@class='oxd-select-text-input']")).click();
		driver.findElement(By.xpath("//input[@class='oxd-input oxd-input--active' and @autocomplete='off']")).sendKeys("smith");
		driver.findElement(By.xpath("//input[@class='oxd-input oxd-input--active' and @type='password' and @autocomplete='off']")).sendKeys("Mahakal@23");
		driver.findElement(By.xpath("//input[@class='oxd-input oxd-input--active' and @type='password' and @autocomplete='off']")).sendKeys("Mahakal@23");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
	}
}
