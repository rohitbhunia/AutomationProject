package OrangePages;

import org.openqa.selenium.WebDriver;

public class base {
	
	WebDriver driver;

	public base(WebDriver driver) {
		this.driver=driver;
	}

}
