package OrangePages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LeavePage extends base{
	public LeavePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public  void leave(String[] args) throws InterruptedException {
		
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
		
		driver.findElement(By.xpath("//span[normalize-space()='Leave']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[normalize-space()='Assign Leave']")).click();
		driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("John Smith");
		
		Thread.sleep(3000);
		
		
		
		
		/*List<WebElement>dynamic=driver.findElements(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div/div/div[2]/div/div"));
		dynamic.get(0).click();
		for(int i=0;i<dynamic.size();i++) {
			dynamic.get(0).sendKeys(Keys.ARROW_DOWN);
		}
		dynamic.get(0).sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("//div[@class='oxd-select-text-input']"));
		Thread.sleep(3000);*/
		List<WebElement>dynamicList=driver.findElements(By.className("oxd-select-text-input"));
		//List<WebElement>dynamicList=driver.findElements(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div"));
		dynamicList.get(0).click();
		for(int i=0;i<dynamicList.size();i++) {
			dynamicList.get(0).sendKeys(Keys.ARROW_DOWN);
			//String text=dynamicList.get(i).getText();
			//System.out.println("Text is"+text);
			
			//if(text.contains("CAN - Personal")) {
				//dynamicList.get(i).click();
				//break;
			//}
		}
		dynamicList.get(0).sendKeys(Keys.ENTER);
		
		driver.findElement(By.xpath("//div[@class='oxd-grid-4 orangehrm-full-width-grid']//div[1]//div[1]//div[2]//div[1]//div[1]//i[1]")).click();
		driver.findElement(By.xpath("//div[contains(text(),'21')]")).click();
		driver.findElement(By.xpath("//div[@class='oxd-form-row']//div[2]//div[1]//div[2]//div[1]//div[1]//i[1]")).click();
		driver.findElement(By.xpath("//div[contains(text(),'28')]")).click();
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		//driver.findElement(By.xpath("//button[normalize-space()='Ok']")).click();
		}
}
