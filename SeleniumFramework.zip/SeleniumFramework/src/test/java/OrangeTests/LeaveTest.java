package OrangeTests;

import org.testng.annotations.Test;

import OrangePages.AdminPage;
import OrangePages.LeavePage;

public class LeaveTest extends AdminTestBase{

	@Test
	public void leave() throws InterruptedException {
		LeavePage page3 =new LeavePage(driver);
		page3.leave(null);
	}
}
