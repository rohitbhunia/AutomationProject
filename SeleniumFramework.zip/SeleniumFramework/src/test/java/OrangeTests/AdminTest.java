package OrangeTests;

import org.testng.annotations.Test;

import OrangePages.AdminPage;

public class AdminTest extends AdminTestBase {

	@Test
	public void login() throws InterruptedException {
		AdminPage page =new AdminPage(driver);
		page.Login();
	}
	
}
