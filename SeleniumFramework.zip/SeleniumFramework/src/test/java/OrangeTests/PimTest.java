package OrangeTests;

import org.testng.annotations.Test;

import OrangePages.AdminPage;
import OrangePages.PimPage;

public class PimTest extends AdminTestBase{

	@Test
	public void pim() throws InterruptedException {
		PimPage page2 =new PimPage(driver);
		page2.pim();;
	}
	
	
}
