package OrangeTests;

import org.testng.annotations.Test;


import OrangePages.TimePage;

public class TimePageTest extends AdminTestBase{
	
	@Test
	public void Time() throws InterruptedException {
		TimePage page4 =new TimePage(driver);
		page4.Time();
	}
	

}
