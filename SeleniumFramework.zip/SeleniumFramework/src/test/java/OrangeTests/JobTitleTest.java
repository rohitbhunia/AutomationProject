package OrangeTests;

import org.testng.annotations.Test;

import OrangePages.AdminPage;
import OrangePages.JobTitlepage;

public class JobTitleTest extends AdminTestBase{

	@Test
	public void JobTtle() throws InterruptedException {
		JobTitlepage page1 =new JobTitlepage(driver);
		page1.JobTitle();
	}
	
}
